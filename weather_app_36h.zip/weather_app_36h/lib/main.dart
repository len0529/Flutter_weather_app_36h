import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:weather_app_36h/client.dart';
import 'package:weather_app_36h/model.dart';

final weatherProvider = FutureProvider<WeatherForecast>((ref) async {
  final client = WeatherApiClient();
  return await client.request();
});

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ProviderScope(
      child: MaterialApp(
        home: WeatherApp(),
      ),
    );
  }
}

class WeatherApp extends StatefulWidget {
  const WeatherApp({super.key});

  @override
  State<WeatherApp> createState() => _WeatherAppState();
}

class _WeatherAppState extends State<WeatherApp> {
  WeatherForecast? weather;
  String searchText = '';
  final TextEditingController searchController = TextEditingController();

  Set<String> timeRangeSet = {};
  List<String> parameterNameList = [];

  void performSearch() async {
    weather = await WeatherApiClient().request();
    String sent = weather!.sent;
    List<LocationData> locations = weather!.locations;

    print("Sent: $sent");

    // 在執行之前清空列表內容
    parameterNameList.clear();
    timeRangeSet.clear(); // 清空時間範圍集合

    for (LocationData location in locations) {
      if (location.locationName == searchText) {
        print("Location: ${location.locationName}");
        List<ElementData> elements = location.elements;

        for (ElementData element in elements) {
          for (TimeData time in element.times) {
            String timeRange = "${time.startTime} - ${time.endTime}";
            timeRangeSet.add(timeRange); // 將時間範圍添加到集合中
            parameterNameList.add(time.parameterName);
          }
        }
      }
    }

    // 將時間範圍集合轉換為列表
    List<String> timeRangeList = timeRangeSet.toList();

    print(timeRangeList);
    print(parameterNameList);
    // 收起鍵盤
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: searchController,
                      decoration: InputDecoration(
                        hintText: "請輸入地點",
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      searchText = searchController.text;
                      performSearch();
                    },
                    child: const Text("Get Data"),
                  ),
                ],
              ),
            ),
            Consumer(builder: (context, ref, child) {
              final weather = ref.watch(weatherProvider);
              return weather.when(
                data: (data) => Text(data.sent),
                loading: () => const CircularProgressIndicator(),
                error: (error, stackTrace) => Text('Error: $error'),
              );
            }),
          ],
        ),
      ),
    );
  }
}