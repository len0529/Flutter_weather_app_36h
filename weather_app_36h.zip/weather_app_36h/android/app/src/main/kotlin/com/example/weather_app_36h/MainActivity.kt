package com.example.weather_app_36h

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
